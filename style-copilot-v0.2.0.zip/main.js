var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => StyleCopilotPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  apiEndpoint: "https://api.openai.com/v1",
  apiKey: "",
  defaultStyle: "",
  enableWeChatExport: true,
  savedStyles: []
};
var StyleCopilotPlugin = class extends import_obsidian.Plugin {
  async onload() {
    await this.loadSettings();
    this.addCommand({
      id: "learn-style",
      name: "\u4ECEURL\u5B66\u4E60\u5199\u4F5C\u98CE\u683C",
      callback: () => {
        new UrlInputModal(this.app, this).open();
      }
    });
    this.addCommand({
      id: "apply-style",
      name: "\u5E94\u7528\u6837\u5F0F\u5230\u5F53\u524D\u7B14\u8BB0",
      callback: () => {
        void this.applyStyleToNote();
      }
    });
    this.addCommand({
      id: "export-wechat",
      name: "\u5BFC\u51FA\u4E3A\u5FAE\u4FE1\u683C\u5F0F",
      callback: () => {
        void this.exportToWeChat();
      }
    });
    this.addCommand({
      id: "manage-styles",
      name: "\u7BA1\u7406\u6837\u5F0F\u6A21\u677F",
      callback: () => {
        new StyleManagerModal(this.app, this).open();
      }
    });
    this.addSettingTab(new StyleCopilotSettingTab(this.app, this));
  }
  onunload() {
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  // ==================== 样式学习功能 ====================
  async learnStyleFromUrl(url) {
    const notice = new import_obsidian.Notice("\u6B63\u5728\u5B66\u4E60\u6837\u5F0F...", 0);
    try {
      const content = await this.fetchArticleContent(url);
      const patterns = this.analyzeStyle(content);
      const template = {
        name: this.extractTitle(content) || `\u6837\u5F0F-${Date.now()}`,
        createdAt: Date.now(),
        source: url,
        patterns
      };
      this.settings.savedStyles.push(template);
      void this.saveSettings();
      notice.hide();
      new import_obsidian.Notice(`\u2705 \u6837\u5F0F\u5B66\u4E60\u6210\u529F: ${template.name}`);
    } catch (error) {
      notice.hide();
      const errorMessage = error instanceof Error ? error.message : String(error);
      new import_obsidian.Notice(`\u274C \u5B66\u4E60\u5931\u8D25: ${errorMessage}`);
      console.error("\u6837\u5F0F\u5B66\u4E60\u9519\u8BEF:", error);
    }
  }
  async fetchArticleContent(url) {
    try {
      const response = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; StyleCopilot/1.0)"
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP\u9519\u8BEF: ${response.status}`);
      }
      const html = await response.text();
      return this.extractTextFromHtml(html);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`\u6293\u53D6\u5931\u8D25: ${errorMessage}`);
    }
  }
  extractTextFromHtml(html) {
    let text = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
    text = text.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "");
    const bodyMatch = text.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    text = bodyMatch ? bodyMatch[1] : text;
    text = text.replace(/<[^>]+>/g, " ");
    text = text.replace(/\s+/g, " ").trim();
    return text;
  }
  extractTitle(content) {
    const titleMatch = content.match(/<title[^>]*>([^<]+)<\/title>/i);
    return titleMatch ? titleMatch[1].trim() : null;
  }
  analyzeStyle(content) {
    const sentences = content.split(/[。！？\n]/).filter((s) => s.trim().length > 0);
    const sentenceLengths = sentences.map((s) => s.trim().length);
    const words = content.split(/\s+/).filter((w) => w.length > 2);
    const wordFreq = {};
    words.forEach((word) => {
      wordFreq[word] = (wordFreq[word] || 0) + 1;
    });
    const keywords = Object.entries(wordFreq).sort((a, b) => b[1] - a[1]).slice(0, 20).map(([word]) => word);
    const paragraphs = content.split(/\n\n+/).filter((p) => p.trim().length > 0);
    const paragraphStructures = paragraphs.map((p) => {
      const length = p.trim().length;
      if (length < 100) return "short";
      if (length < 300) return "medium";
      return "long";
    });
    return {
      sentenceLength: sentenceLengths.slice(0, 50),
      vocabulary: keywords.slice(0, 50),
      paragraphStructure: paragraphStructures,
      tone: "neutral",
      keywords
    };
  }
  // ==================== 样式应用功能 ====================
  applyStyleToNote() {
    const activeFile = this.app.workspace.getActiveFile();
    if (!activeFile) {
      new import_obsidian.Notice("\u274C \u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u7B14\u8BB0");
      return;
    }
    if (this.settings.savedStyles.length === 0) {
      new import_obsidian.Notice("\u274C \u6CA1\u6709\u4FDD\u5B58\u7684\u6837\u5F0F\u6A21\u677F\uFF0C\u8BF7\u5148\u5B66\u4E60\u6837\u5F0F");
      return;
    }
    new StyleSelectionModal(this.app, this, activeFile).open();
  }
  async applyStyle(file, style) {
    const notice = new import_obsidian.Notice("\u6B63\u5728\u5E94\u7528\u6837\u5F0F...", 0);
    try {
      const content = await this.app.vault.read(file);
      const styledContent = this.transformContent(content, style);
      await this.app.vault.modify(file, styledContent);
      notice.hide();
      new import_obsidian.Notice(`\u2705 \u6837\u5F0F\u5E94\u7528\u6210\u529F: ${style.name}`);
    } catch (error) {
      notice.hide();
      const errorMessage = error instanceof Error ? error.message : String(error);
      new import_obsidian.Notice(`\u274C \u5E94\u7528\u5931\u8D25: ${errorMessage}`);
      console.error("\u6837\u5F0F\u5E94\u7528\u9519\u8BEF:", error);
    }
  }
  transformContent(content, style) {
    const lines = content.split("\n");
    const transformedLines = lines.map((line) => {
      if (line.startsWith("#") || line.startsWith("```")) {
        return line;
      }
      return this.adjustSentence(line, style.patterns);
    });
    return transformedLines.join("\n");
  }
  adjustSentence(sentence, style) {
    if (style.sentenceLength.length === 0) {
      return sentence;
    }
    const avgLength = style.sentenceLength.reduce((a, b) => a + b, 0) / style.sentenceLength.length;
    const currentLength = sentence.length;
    if (currentLength > avgLength * 1.5) {
    }
    return sentence;
  }
  // ==================== 微信导出功能 ====================
  async exportToWeChat() {
    const activeFile = this.app.workspace.getActiveFile();
    if (!activeFile) {
      new import_obsidian.Notice("\u274C \u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u7B14\u8BB0");
      return;
    }
    const notice = new import_obsidian.Notice("\u6B63\u5728\u5BFC\u51FA...", 0);
    try {
      const content = await this.app.vault.read(activeFile);
      const wechatContent = this.convertToWeChatFormat(content);
      await navigator.clipboard.writeText(wechatContent);
      notice.hide();
      new import_obsidian.Notice("\u2705 \u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F\uFF0C\u53EF\u76F4\u63A5\u7C98\u8D34\u5230\u5FAE\u4FE1");
    } catch (error) {
      notice.hide();
      const errorMessage = error instanceof Error ? error.message : String(error);
      new import_obsidian.Notice(`\u274C \u5BFC\u51FA\u5931\u8D25: ${errorMessage}`);
      console.error("\u5FAE\u4FE1\u5BFC\u51FA\u9519\u8BEF:", error);
    }
  }
  convertToWeChatFormat(content) {
    let result = content;
    result = result.replace(/^### (.*$)/gm, "**$1**\n");
    result = result.replace(/^## (.*$)/gm, "**$1**\n");
    result = result.replace(/^# (.*$)/gm, "**$1**\n");
    result = result.replace(/\*\*(.*?)\*\*/g, "$1");
    result = result.replace(/\*(.*?)\*/g, "$1");
    result = result.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1 ($2)");
    result = result.replace(/^- (.*$)/gm, "\u2022 $1");
    result = result.replace(/^\* (.*$)/gm, "\u2022 $1");
    result = result.replace(/```[\s\S]*?```/g, (match) => {
      return match.replace(/```\w*\n?/g, "").split("\n").map((line) => `  ${line}`).join("\n");
    });
    result = result.replace(/`([^`]+)`/g, "$1");
    result = result.replace(/\n{3,}/g, "\n\n");
    return result.trim();
  }
};
var UrlInputModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "\u4ECEURL\u5B66\u4E60\u5199\u4F5C\u98CE\u683C" });
    const container = contentEl.createDiv({ cls: "style-copilot-container" });
    const urlInput = container.createEl("input", {
      type: "text",
      placeholder: "\u8F93\u5165\u6587\u7AE0URL",
      cls: "style-copilot-input"
    });
    urlInput.style.width = "100%";
    urlInput.style.marginBottom = "10px";
    const buttonContainer = container.createDiv();
    buttonContainer.style.display = "flex";
    buttonContainer.style.gap = "10px";
    const learnButton = buttonContainer.createEl("button", {
      text: "\u5F00\u59CB\u5B66\u4E60",
      cls: "style-copilot-button"
    });
    learnButton.style.flex = "1";
    const cancelButton = buttonContainer.createEl("button", {
      text: "\u53D6\u6D88",
      cls: "style-copilot-button"
    });
    cancelButton.style.flex = "1";
    learnButton.addEventListener("click", () => {
      const url = urlInput.value.trim();
      if (!url) {
        new import_obsidian.Notice("\u8BF7\u8F93\u5165URL");
        return;
      }
      this.close();
      void this.plugin.learnStyleFromUrl(url);
    });
    cancelButton.addEventListener("click", () => {
      this.close();
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var StyleSelectionModal = class extends import_obsidian.Modal {
  constructor(app, plugin, file) {
    super(app);
    this.plugin = plugin;
    this.file = file;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "\u9009\u62E9\u6837\u5F0F\u6A21\u677F" });
    const container = contentEl.createDiv({ cls: "style-copilot-container" });
    this.plugin.settings.savedStyles.forEach((style) => {
      const styleItem = container.createDiv({
        cls: "style-copilot-result"
      });
      styleItem.style.marginBottom = "10px";
      styleItem.style.cursor = "pointer";
      styleItem.createEl("div", {
        text: style.name,
        cls: "style-copilot-header"
      });
      const meta = styleItem.createEl("div", {
        text: `\u6765\u6E90: ${style.source}
\u521B\u5EFA\u65F6\u95F4: ${new Date(style.createdAt).toLocaleString()}`
      });
      meta.style.fontSize = "0.9em";
      meta.style.color = "var(--text-muted)";
      styleItem.addEventListener("click", () => {
        this.close();
        void this.plugin.applyStyle(this.file, style);
      });
    });
    const cancelButton = container.createEl("button", {
      text: "\u53D6\u6D88",
      cls: "style-copilot-button"
    });
    cancelButton.style.marginTop = "10px";
    cancelButton.addEventListener("click", () => {
      this.close();
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var StyleManagerModal = class extends import_obsidian.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "\u7BA1\u7406\u6837\u5F0F\u6A21\u677F" });
    const container = contentEl.createDiv({ cls: "style-copilot-container" });
    if (this.plugin.settings.savedStyles.length === 0) {
      container.createEl("div", {
        text: "\u6682\u65E0\u4FDD\u5B58\u7684\u6837\u5F0F\u6A21\u677F",
        cls: "style-copilot-result"
      });
    } else {
      this.plugin.settings.savedStyles.forEach((style, index) => {
        const styleItem = container.createDiv({
          cls: "style-copilot-result"
        });
        styleItem.style.marginBottom = "10px";
        const header = styleItem.createDiv();
        header.style.display = "flex";
        header.style.justifyContent = "space-between";
        header.style.alignItems = "center";
        header.createEl("div", {
          text: style.name,
          cls: "style-copilot-header"
        });
        const deleteButton = header.createEl("button", {
          text: "\u5220\u9664",
          cls: "style-copilot-button"
        });
        deleteButton.style.padding = "4px 8px";
        deleteButton.style.fontSize = "0.9em";
        deleteButton.addEventListener("click", () => {
          this.plugin.settings.savedStyles.splice(index, 1);
          void this.plugin.saveSettings();
          new import_obsidian.Notice("\u6837\u5F0F\u5DF2\u5220\u9664");
          this.onOpen();
        });
        const meta = styleItem.createEl("div", {
          text: `\u6765\u6E90: ${style.source}
\u521B\u5EFA\u65F6\u95F4: ${new Date(style.createdAt).toLocaleString()}`
        });
        meta.style.fontSize = "0.9em";
        meta.style.color = "var(--text-muted)";
      });
    }
    const closeButton = container.createEl("button", {
      text: "\u5173\u95ED",
      cls: "style-copilot-button"
    });
    closeButton.style.marginTop = "10px";
    closeButton.addEventListener("click", () => {
      this.close();
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var StyleCopilotSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Style Copilot \u8BBE\u7F6E" });
    new import_obsidian.Setting(containerEl).setName("API\u7AEF\u70B9").setDesc("\u7528\u4E8E\u6837\u5F0F\u5206\u6790\u7684API\u7AEF\u70B9\uFF08\u53EF\u9009\uFF09").addText((text) => text.setPlaceholder("https://api.openai.com/v1").setValue(this.plugin.settings.apiEndpoint).onChange(async (value) => {
      this.plugin.settings.apiEndpoint = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("API\u5BC6\u94A5").setDesc("\u7528\u4E8EAI\u589E\u5F3A\u529F\u80FD\u7684API\u5BC6\u94A5\uFF08\u53EF\u9009\uFF09").addText((text) => text.setPlaceholder("sk-...").setValue(this.plugin.settings.apiKey).onChange(async (value) => {
      this.plugin.settings.apiKey = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("\u9ED8\u8BA4\u6837\u5F0F").setDesc("\u9ED8\u8BA4\u5E94\u7528\u7684\u5199\u4F5C\u6837\u5F0F").addText((text) => text.setPlaceholder("\u8F93\u5165\u6837\u5F0F\u540D\u79F0").setValue(this.plugin.settings.defaultStyle).onChange(async (value) => {
      this.plugin.settings.defaultStyle = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("\u542F\u7528\u5FAE\u4FE1\u5BFC\u51FA").setDesc("\u542F\u7528\u5BFC\u51FA\u4E3A\u5FAE\u4FE1\u683C\u5F0F\u7684\u529F\u80FD").addToggle((toggle) => toggle.setValue(this.plugin.settings.enableWeChatExport).onChange(async (value) => {
      this.plugin.settings.enableWeChatExport = value;
      await this.plugin.saveSettings();
    }));
    containerEl.createEl("h3", { text: "\u5DF2\u4FDD\u5B58\u7684\u6837\u5F0F" });
    const styleCount = containerEl.createEl("div", {
      text: `\u5171 ${this.plugin.settings.savedStyles.length} \u4E2A\u6837\u5F0F\u6A21\u677F`
    });
    styleCount.style.marginBottom = "10px";
    styleCount.style.color = "var(--text-muted)";
  }
};
