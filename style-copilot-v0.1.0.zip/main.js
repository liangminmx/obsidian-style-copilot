var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => StyleCopilotPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  apiEndpoint: "https://api.openai.com/v1",
  defaultStyle: "",
  enableWeChatExport: true
};
var StyleCopilotPlugin = class extends import_obsidian.Plugin {
  async onload() {
    await this.loadSettings();
    this.addCommand({
      id: "learn-style",
      name: "\u4ECEURL\u5B66\u4E60\u5199\u4F5C\u98CE\u683C",
      callback: () => {
        this.learnStyleFromUrl();
      }
    });
    this.addCommand({
      id: "apply-style",
      name: "\u5E94\u7528\u6837\u5F0F\u5230\u5F53\u524D\u7B14\u8BB0",
      callback: () => {
        this.applyStyleToNote();
      }
    });
    this.addCommand({
      id: "export-wechat",
      name: "\u5BFC\u51FA\u4E3A\u5FAE\u4FE1\u683C\u5F0F",
      callback: () => {
        this.exportToWeChat();
      }
    });
    this.addSettingTab(new StyleCopilotSettingTab(this.app, this));
  }
  onunload() {
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  learnStyleFromUrl() {
  }
  applyStyleToNote() {
  }
  exportToWeChat() {
  }
};
var StyleCopilotSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Style Copilot \u8BBE\u7F6E" });
    new import_obsidian.Setting(containerEl).setName("API\u7AEF\u70B9").setDesc("\u7528\u4E8E\u6837\u5F0F\u5206\u6790\u7684API\u7AEF\u70B9").addText((text) => text.setPlaceholder("https://api.openai.com/v1").setValue(this.plugin.settings.apiEndpoint).onChange(async (value) => {
      this.plugin.settings.apiEndpoint = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("\u9ED8\u8BA4\u6837\u5F0F").setDesc("\u9ED8\u8BA4\u5E94\u7528\u7684\u5199\u4F5C\u6837\u5F0F").addText((text) => text.setPlaceholder("\u8F93\u5165\u6837\u5F0F\u540D\u79F0").setValue(this.plugin.settings.defaultStyle).onChange(async (value) => {
      this.plugin.settings.defaultStyle = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("\u542F\u7528\u5FAE\u4FE1\u5BFC\u51FA").setDesc("\u542F\u7528\u5BFC\u51FA\u4E3A\u5FAE\u4FE1\u683C\u5F0F\u7684\u529F\u80FD").addToggle((toggle) => toggle.setValue(this.plugin.settings.enableWeChatExport).onChange(async (value) => {
      this.plugin.settings.enableWeChatExport = value;
      await this.plugin.saveSettings();
    }));
  }
};
